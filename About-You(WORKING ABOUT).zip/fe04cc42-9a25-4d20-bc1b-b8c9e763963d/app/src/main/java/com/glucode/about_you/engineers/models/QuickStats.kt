package com.glucode.about_you.engineers.models

data class QuickStats(
    val years: Int,
    val coffees: Int,
    val bugs: Int
)