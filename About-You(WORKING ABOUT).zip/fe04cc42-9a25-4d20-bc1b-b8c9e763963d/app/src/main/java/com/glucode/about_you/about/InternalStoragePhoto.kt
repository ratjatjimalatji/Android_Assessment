package com.glucode.about_you.about

import android.graphics.Bitmap

data class InternalStoragePhoto (
    val name: String,
    val bmp: Bitmap
)