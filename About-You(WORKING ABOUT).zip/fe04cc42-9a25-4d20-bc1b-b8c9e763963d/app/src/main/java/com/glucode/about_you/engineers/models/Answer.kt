package com.glucode.about_you.engineers.models

data class Answer(
    val text: String?,
    val index : Int?
)