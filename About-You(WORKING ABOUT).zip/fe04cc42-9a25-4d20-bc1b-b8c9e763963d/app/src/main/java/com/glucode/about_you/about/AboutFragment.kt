package com.glucode.about_you.about

import android.content.Context.MODE_PRIVATE
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.fragment.app.Fragment
import com.glucode.about_you.about.views.QuestionCardView
import com.glucode.about_you.databinding.FragmentAboutBinding
import com.glucode.about_you.mockdata.MockData
import java.io.IOException

class AboutFragment: Fragment() {
    private lateinit var binding: FragmentAboutBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAboutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setUpQuestions()
    }

//    private suspend fun loadPhotoFromInternalStorage():List<InternalStoragePhoto>{
//
//
//    }
//private fun savePhotoToInternalStorage(filename:String, bmp: Bitmap): Boolean{
//    return try{
//        //Output stream
//        openFileOutput("$filename.jpg", MODE_PRIVATE).use{ stream ->
//            if(!bmp.compress(Bitmap.CompressFormat.JPEG, 95, stream)){
//                throw IOException("Couldn't save bitmap")
//            }
//        }
//        true
//    }catch (e: IOException){
//        e.printStackTrace()
//        false
//    }
//}
    private fun setUpQuestions() {
        val engineerName = arguments?.getString("name")
        val engineer = MockData.engineers.first { it.name == engineerName }

        engineer.questions.forEach { question ->
            val questionView = QuestionCardView(requireContext())
            questionView.title = question.questionText
            questionView.answers = question.answerOptions
            questionView.selection = question.answer.index

            binding.container.addView(questionView)
        }
    }
}